#include "AssetManager.h"
#include <iostream>
using namespace std;

AssetManager::AssetManager()
{
	cout << "\n" << "\n" << "Asset Manager Object Constructor Started";

	cout << "\n" << "Asset Manager Constructed" << "\n";
}

AssetManager::~AssetManager()
{
	cout << "\n" << "\n" << "Asset Manager Object Destruction Started";
	
	cout << "\n" << "Asset Manager Destructed" << "\n";
}

void AssetManager::Initialize()
{
	cout << "\n" << "\n" << "Asset Manager Initialize Started";

	cout << "\n" << "Asset Manager Initialize Ended" << "\n";
}

void AssetManager::Destroy()
{
	cout << "\n" << "\n" << "Asset Manager Destroy Started";
	this->~AssetManager();
	cout << "\n" << "Asset Manager Destroy Ended" << "\n";
}

void AssetManager::Update()
{
	cout << "\n" << "\n" << "Asset Manager Update Started";

	cout << "\n" << "Asset Manager Update Ended" << "\n";
}

void AssetManager::Load()
{
	cout << "\n" << "\n" << "Asset Manager Load Started";

	cout << "\n" << "Asset Manager Load Ended" << "\n";
}
