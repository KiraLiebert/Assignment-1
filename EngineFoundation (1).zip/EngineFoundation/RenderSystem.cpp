
#include "RenderSystem.h"
#include <iostream>


#include "json.hpp";
using namespace json;

RenderSystem::RenderSystem()
{
	cout << "\n" << "\n" << "RenderSystem Constructor Started";

	cout << "\n" << "RenderSystem Constructor Ended" << "\n";
}

RenderSystem::~RenderSystem()
{
	cout << "\n" << "\n" << "RenderSystem Destructor Started";

	cout << "\n" << "RenderSystem Destructor Ended" << "\n";
}

void RenderSystem::Initialize(JSON document)
{
	cout << "\n" << "\n" <<"RenderSystem Initialize Started" << "\n";

	string name = "";
	int width, height = 0;
	bool fullscreen = false;

	if (document.hasKey("RenderSystem"))
	{
		json::JSON subObject = document["RenderSystem"];
		if (subObject.hasKey("Name"))
		{
			name = subObject["Name"].ToString();
			cout << "\n" << "				Render System - Name: " << name;
		}
		if (subObject.hasKey("width"))
		{
			width = subObject["width"].ToInt();
			cout << "\n" << "				Render System - Width: " << width;
		}
		if (subObject.hasKey("height"))
		{
			height = subObject["height"].ToInt();
			cout << "\n" << "				Render System - Height: " << height;
		}
		if (subObject.hasKey("fullscreen"))
		{
			fullscreen = subObject["fullscreen"].ToBool();
			cout << "\n" << "				Render System - Fullscreen: " << fullscreen;
		}
	}



	cout << "\n" << "\n" << "RenderSystem Initialize Ended" << "\n";

}



void RenderSystem::Destroy()
{
	cout << "\n" << "\n" << "RenderSystem Destroy Started";
	this->~RenderSystem();
	cout << "\n" << "RenderSystem Destroy Ended" << "\n";
}

void RenderSystem::Update()
{
	cout << "\n" << "\n" << "RenderSystem Update Started";

	cout << "\n" << "RenderSystem Update Ended" << "\n";
}

void RenderSystem::Load()
{
	cout << "\n" << "\n" << "RenderSystem Load Started";

	cout << "\n" << "RenderSystem Load Ended" << "\n";
}
