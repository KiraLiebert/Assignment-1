#include "Component.h"
#include <iostream>
#include "JSON.h"
using namespace json;
using namespace std;

Component::Component()
{
	cout << "\n" << "\n" << "Component Constructor Started";

	cout << "\n" << "Component Constructor Ended" << "\n";
}

Component::~Component()
{
	cout << "\n" << "\n" << "Component Destructor Started";

	cout << "\n" << "Component Destructor Ended" << "\n";
}

void Component::Initialize()
{
	cout << "\n" << "\n" << "Component Initialize Started";

	cout << "\n" << "Component Initialize Ended" << "\n";
}

void Component::Destroy()
{
	cout << "\n" << "\n" << "Component Destroy Started";
	this->~Component();
	cout << "\n" << "Component Destroy Ended" << "\n";
}

int Component::GetComponentId()
{
	cout << "\n" << "\n" << "Running Component GetComponentId" << "\n";
	return 0;
}

void Component::Update()
{
	cout << "\n" << "\n" << "Component Update Started";

	cout << "\n" << "Component Update Ended" << "\n";
}

void Component::Load(JSON document)
{
	cout << "\n" << "\n" << "Component Load Started";

	if (document.hasKey("className"))
	{
		string cname = document["className"].ToString();
		cout << "\n" << "				Component ClassName: " << cname;
	}
	if (document.hasKey("id"))
	{
		id = document["id"].ToInt();
		cout << "\n" << "				ComponentId: " << id;
	}
	cout << "\n" << "Component Load Ended" << "\n";
}
