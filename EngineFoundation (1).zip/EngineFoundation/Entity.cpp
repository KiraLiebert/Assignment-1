#include "Entity.h"
#include <iostream>
#include "JSON.h"
using namespace json;
using namespace std;

Entity::Entity()
{
	cout << "\n" << "\n" << "Entity Constructor Started";

	cout << "\n" << "Entity Constructor Ended" << "\n";
}

Entity::~Entity()
{
	cout << "\n" << "\n" << "Entity Destructor Started";

	cout << "\n" << "Entity Destructor Ended" << "\n";
}

void Entity::Initialize()
{
	cout << "\n" << "\n" << "Entity Initialize Started";
	for (Component c : components)
	{
		c.Initialize();
	}
	cout << "\n" << "Entity Initialize Ended" << "\n";
}

void Entity::Destroy()
{
	cout << "\n" << "\n" << "Entity Destroy Started";
	for (Component c : components)
	{
		c.Destroy();
	}
	this->~Entity();
	cout << "\n" << "Entity Destroy Ended" << "\n";
}

void Entity::AddComponent(Component* _component)
{
	cout << "\n" << "\n" << "Entity AddComponent Started";

	cout << "\n" << "Entity AddComponent Ended" << "\n";
}

void Entity::RemoveComponent(Component* _component)
{
	cout << "\n" << "\n" << "Entity RemoveComponent Started";

	cout << "\n" << "Entity RemoveComponent Ended" << "\n";
}

void Entity::Update()
{
	cout << "\n" << "\n" << "Entity Update Started";
	for (Component c : components)
	{
		c.Update();
	}
	cout << "\n" << "Entity Update Ended" << "\n";
}

string& Entity::GetName()
{

	cout << "\n" << "\n" << "Running Entity GetName" << "\n";
	return this->name;
}

void Entity::Load(JSON document)
{
	cout << "\n" << "\n" << "Entity Load Started";

	
	if (document.hasKey("Name"))
	{
		string name = document["Name"].ToString();
		cout << "\n" << "				Entity Name: " << name;
	}
	cout << "\n" << "Adding Components";
	if (document.hasKey("Components"))
	{
		JSON cp = document["Components"];
		for (auto& comp : cp.ArrayRange())
		{
			Component c;
			c.Initialize();
			c.Load(comp);
			components.push_back(c);
		}
	}

	cout << "\n" << "Entity Load Ended" << "\n";
}
