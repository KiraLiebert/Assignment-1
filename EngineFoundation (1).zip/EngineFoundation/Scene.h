#pragma once
#include<list>
#include "Entity.h"
#include "json.h";
using namespace json;
using namespace std;

class Scene
{
private:
	list<Entity> entities;
public:
	Scene();
	~Scene();
	void Initialize();
	void Destroy();
	void Update();
	void AddEntity(Entity* _entity);
	void RemoveEntity(Entity* _entity);
	void Load(JSON);
};

