
#pragma once

#include "json.h";
#include <string>
#include <iostream>
#include <string>
using namespace std;
using namespace json;

class RenderSystem
{
private:
	std::string name;
	int width;
	int height;
	bool fullscreen;
public:
	RenderSystem();
	~RenderSystem();
	void Initialize(JSON);
	void Destroy();
	void Update();
	void Load();
};

