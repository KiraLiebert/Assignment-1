#include "Object.h"
#include <iostream>
using namespace std;

Object::Object()
{
	cout << "\n" << "\n" << "Object Constructor Started";

	cout << "\n" << "Object Constructor Ended" << "\n";
}

Object::~Object()
{
	cout << "\n" << "\n" << "Object Destructor Started";

	cout << "\n" << "Object Destructor Ended" << "\n";
}

void Object::Initialize()
{
	cout << "\n" << "\n" << "Object Initialize Started";

	cout << "\n" << "Object Initialize Ended" << "\n";
}

void Object::Destroy()
{
	cout << "\n" << "\n" << "Object Destroy Started";
	this->~Object();
	cout << "\n" << "Object Destroy Ended" << "\n";
}

bool Object::IsInitialized()
{
	cout << "\n" << "\n" << "Running Object IsInitialized" <<"/n";

	return false;
}

void Object::Load()
{
	cout << "\n" << "\n" << "Object Load Started";

	cout << "\n" << "Object Load Ended" << "\n";
}
