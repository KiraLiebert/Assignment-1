#pragma once
#include "Scene.h"
#include<list>

using namespace std;

class SceneManager
{
private:
	list<Scene> scenes;
public:
	SceneManager();
	~SceneManager();
	void Initialize();
	void Destroy();
	void Update();
	void AddScene(Scene* _scene);
	void RemoveScene(Scene* _scene);
	void Load(JSON);
};

