#include "SceneManager.h"
#include <iostream>
#include "JSON.h"
using namespace json;

using namespace std;

SceneManager::SceneManager()
{
	cout << "\n" << "\n" << "Scene Manager Constructor Started";

	cout << "\n" << "Scene Manager Constructor Ended" << "\n";
}

SceneManager::~SceneManager()
{
	cout << "\n" << "\n" << "Scene Manager Destructor Started";

	cout << "\n" << "Scene Manager Destructor Ended" << "\n";
}

void SceneManager::Initialize()
{
	cout << "\n" << "\n" << "Scene Manager Initialize Started";
	for (Scene s : scenes)
	{
		s.Initialize();
	}
	cout << "\n" << "Scene Manager Initialize Ended" << "\n";
}

void SceneManager::Destroy()
{
	cout << "\n" << "\n" << "Scene Manager Destroy Started";

	this->~SceneManager();

	cout << "\n" << "Scene Manager Destroy Ended" << "\n";
}

void SceneManager::Update()
{
	cout << "\n" << "\n" << "Scene Manager Update Started";
	for (Scene s : scenes)
	{
		s.Update();
	}
	cout << "\n" << "Scene Manager Update Ended" << "\n";
}

void SceneManager::AddScene(Scene* _scene)
{
	cout << "\n" << "\n" << "Scene Manager AddScene Started";

	cout << "\n" << "Scene Manager AddScene Ended" << "\n";
}

void SceneManager::RemoveScene(Scene* _scene)
{
	cout << "\n" << "\n" << "Scene Manager RemoveScene Started";

	cout << "\n" << "Scene Manager RemoveScene Ended" << "\n";
}

void SceneManager::Load(JSON document)
{
	cout << "\n" << "\n" << "Scene Manager Load Started";

	cout << "\n" << "				Adding Scenes";
	for (auto& scene : document.ArrayRange())
	{
		Scene s;
		s.Initialize();
		s.Load(scene);
		scenes.push_back(s);
	}

	cout << "\n" << "Scene Manager Load Ended" << "\n";
}
