#include "Engine.h"
#include <iostream>
#include <string>
#include <fstream>
#include "json.h";
using namespace json;



using namespace std;
Engine::Engine()
{
	cout << "\n" << "\n" << "Engine Object Constructor Started";

	cout <<"\n" << "Engine Object Created" << "\n";
}

Engine::~Engine()
{
	cout << "\n" << "\n" << "Engine Object Destructor Started";

	//renderSystem = new RenderSystem();
	//this->assetManager = new AssetManager();
	
	cout << "\n" << "Engine Object Destructed" << "\n";
}

void Engine::Initialize()
{

	cout << "\n" <<  "\n" << "Engine Initialize Started";
	ifstream inputStream("GameSettings.json");
	string str((istreambuf_iterator<char>(inputStream)), istreambuf_iterator<char>());
	JSON document = JSON::Load(str);
	string EngineFileName;
	if (document.hasKey("Engine"))
	{
		JSON subObject = document["Engine"];
		if (subObject.hasKey("DefaultFile"))
		{
			EngineFileName = subObject["DefaultFile"].ToString();
			cout <<  "\n" << "				EngineFileName: " << EngineFileName << "\n";
		}
	}


	// Loading GameLevelsFile

	ifstream inputStream2(EngineFileName);
	string str2((istreambuf_iterator<char>(inputStream2)), istreambuf_iterator<char>());
	JSON document2 = JSON::Load(str2);
	if (document2.hasKey("SceneManager"))
	{
		JSON sm = document2["SceneManager"];
		sceneManager.Load(sm);
	}

	//Initialize Value for Render System
	renderSystem.Initialize(document2);

	assetManager.Initialize();
	inputManager.Initialize();
	sceneManager.Initialize();
	cout << "\n" << "Engine Initialize Ended" << "\n";
}

void Engine::Destroy()
{
	cout << "\n" << "\n" << "Engine Destroy Started";

	this->~Engine();

	cout << "\n" << "Engine Destroy Ended" << "\n";
}

void Engine::GameLoop()
{
	cout << "\n" << "\n" << "Engine GameLoop Started";
	assetManager.Update();
	renderSystem.Update();
	inputManager.Update();
	sceneManager.Update();
	cout << "\n" << "Engine GameLoop Ended" << "\n";
}

void Engine::Load()
{
	cout << "\n" << "\n" << "Engine Load Started";

	cout << "\n" << "Engine Load Ended" << "\n";
}
