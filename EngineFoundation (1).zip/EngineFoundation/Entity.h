#pragma once
#include<list>
#include "Component.h"
#include <string>
#include "json.h";
using namespace json;
using namespace std;

class Entity
{
private:
	list<Component> components;
	string name;
public:
	Entity();
	~Entity();
	void Initialize();
	void Destroy();
	void AddComponent(Component* _component);
	void RemoveComponent(Component* _component);
	void Update();
	string& GetName();
	void Load(JSON);
};

