#pragma once
class InputManager
{

public:
	InputManager();
	~InputManager();
	void Initialize();
	void Destroy();
	void Update();
	void Load();
};

