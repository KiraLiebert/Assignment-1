#include "InputManager.h"
#include <iostream>
using namespace std;



InputManager::InputManager()
{
	cout << "\n" << "Input Manager Constructor Started";

	cout << "\n" << "Input Manager Constructed";
}

InputManager::~InputManager()
{
	cout << "\n" << "Input Manager Destruction Started";

	cout << "\n" << "Input Manager Destructed";
}

void InputManager::Initialize()
{
	cout << "\n" << "Input Manager Initialize Started";

	cout << "\n" << "Input Manager Initialize Ended";
}

void InputManager::Destroy()
{
	cout << "\n" << "Input Manager Initialize Started";
	this->~InputManager();
	cout << "\n" << "Input Manager Initialize Ended";
}

void InputManager::Update()
{
	cout << "\n" << "Input Manager Update Started";

	cout << "\n" << "Input Manager Update Ended";
}

void InputManager::Load()
{
	cout << "\n" << "Input Manager Load Started";

	cout << "\n" << "Input Manager Load Ended";
}
