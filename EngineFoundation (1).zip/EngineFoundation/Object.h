#pragma once
class Object
{
private:
	bool initialized;

public:
	Object();
	~Object();
	void Initialize();
	void Destroy();
	bool IsInitialized();
	void Load();
};

