#include "Scene.h"
#include <iostream>
#include "JSON.h"
using namespace json;
using namespace std;
Scene::Scene()
{
	cout << "\n" << "\n" << "Scene Constructor Started";

	cout<< "\n"  << "\n" << "Scene Constructor Ended";
}

Scene::~Scene()
{
	cout << "\n" << "\n" << "Scene Destructor Started";

	cout << "\n" << "Scene Destructor Ended" << "\n";
}

void Scene::Initialize()
{
	cout << "\n" << "\n" << "Scene Initialize Started";
	for (Entity e : entities)
	{
		e.Initialize();
	}
	cout << "\n" << "Scene Initialize Ended" << "\n";
}

void Scene::Destroy()
{
	cout << "\n" << "\n" << "Scene Destroy Started";

	this->~Scene();
	cout << "\n" << "Scene Destroy Ended" << "\n";

}

void Scene::Update()
{
	cout << "\n" << "\n" << "Scene Update Started";
	for (Entity e : entities)
	{
		e.Update();
	}
	cout << "\n" << "Scene Update Ended" << "\n";
}

void Scene::AddEntity(Entity* _entity)
{
	cout << "\n" << "\n" << "Scene AddEntity Started";

	cout << "\n" << "Scene AddEntity Ended" << "\n";
}

void Scene::RemoveEntity(Entity* _entity)
{
	cout << "\n" << "\n" << "Scene RemoveEntity Started";
	

	cout << "\n" << "Scene RemoveEntity Ended" << "\n";
}

void Scene::Load(JSON document)
{
	cout << "\n" << "\n" << "Scene Load Started";
	cout << "\n" << "Adding Scene";
	if (document.hasKey("name"))
	{
		string name = document["name"].ToString();
		cout << "\n" << "				Scene Name: " << name;
	}
	if (document.hasKey("Entities"))
	{
		JSON sm = document["Entities"];
		for (auto& entity : sm.ArrayRange())
		{
			Entity e;
			e.Initialize();
			e.Load(entity);
			entities.push_back(e);
		}
	}

	cout << "\n" << "Scene Load Ended" << "\n";
}
