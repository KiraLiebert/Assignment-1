#pragma once
#include "JSON.h"
using namespace json;
class Component
{
private:
	int id;

public:
	Component();
	~Component();
	void Initialize();
	void Destroy();
	int GetComponentId();
	void Update();
	void Load(JSON);
};

